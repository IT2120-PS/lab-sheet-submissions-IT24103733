# Lab Sheet 04 - IT24103733

# 1.
setwd("C:/Users/it24103733/Desktop/IT24103733-Lab4")
branch_data <- read.csv("Exercise.txt", header = TRUE, stringsAsFactors = FALSE)

# 2. Inspect structure 
str(branch_data)
# sales        -> Sales_X1, numeric, ratio
# advertising  -> Advertising_X2, numeric, ratio
# years        -> Years_X3, integer, ratio

# 3
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales",
        notch = TRUE)

# 4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

# 5
find_outliers <- function(x) {
  q <- quantile(x, probs = c(0.25, 0.75), na.rm = TRUE)
  iqr <- q[2] - q[1]
  lower <- q[1] - 1.5 * iqr
  upper <- q[2] + 1.5 * iqr
  x[x < lower | x > upper]
}
find_outliers(branch_data$Years_X3)

# 6
find_modes <- function(x) {
  ux <- unique(x)
  freqs <- tabulate(match(x, ux))
  ux[freqs == max(freqs)]
}
find_modes(branch_data$Years_X3)
